﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace AplikacijaZaBiblioteku
{
    public partial class Pretraga : Form
    {
        public Pretraga()
        {
            InitializeComponent();
        }

        private void PretragaButun_Click(object sender, EventArgs e)
        {

        }

        private void ZatvoriButun_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}
